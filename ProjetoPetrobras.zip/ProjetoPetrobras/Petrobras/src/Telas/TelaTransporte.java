package Telas;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class TelaTransporte extends JFrame {

	private JPanel contentPane;
	private JTextField txtcodigo;
	private JTextField txtdataCompra;
	private JTextField txtdataEntrega;
	private JTextField txtquantidade;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaTransporte frame = new TelaTransporte();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaTransporte() {
		setResizable(false);
		setTitle("Tela Principal de Transporte - Petrobras");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 527, 506);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(TelaTransporte.class.getResource("/imagens/login (1).jpg")));
		lblNewLabel.setBounds(10, 121, 195, 198);
		contentPane.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(new Color(46, 139, 87));
		panel.setBounds(204, 0, 307, 470);
		contentPane.add(panel);
		
		JLabel lblNewLabel_1 = new JLabel("Código do Pedido:");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(10, 83, 100, 14);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Data da Compra:");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(21, 193, 89, 14);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Data de Entrega:");
		lblNewLabel_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_2.setBounds(21, 218, 89, 14);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Quantidade:");
		lblNewLabel_1_3.setForeground(Color.WHITE);
		lblNewLabel_1_3.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_3.setBounds(44, 243, 66, 14);
		panel.add(lblNewLabel_1_3);
		
		txtcodigo = new JTextField();
		txtcodigo.setBounds(120, 80, 144, 20);
		panel.add(txtcodigo);
		txtcodigo.setColumns(10);
		
		txtdataCompra = new JTextField();
		txtdataCompra.setEditable(false);
		txtdataCompra.setColumns(10);
		txtdataCompra.setBounds(120, 189, 144, 20);
		panel.add(txtdataCompra);
		
		txtdataEntrega = new JTextField();
		txtdataEntrega.setEditable(false);
		txtdataEntrega.setColumns(10);
		txtdataEntrega.setBounds(120, 215, 144, 20);
		panel.add(txtdataEntrega);
		
		txtquantidade = new JTextField();
		txtquantidade.setEditable(false);
		txtquantidade.setColumns(10);
		txtquantidade.setBounds(120, 240, 144, 20);
		panel.add(txtquantidade);
		
		JButton cad = new JButton("Consultar");
		cad.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				
				cad.setCursor(new Cursor(Cursor.HAND_CURSOR));
				
			}
		});
		cad.setBackground(new Color(255, 255, 255));
		cad.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
try {
					
					//INVOCAR O CONECTOR DO BANCO DE DADOS:
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					
					// REALIZAR A CONEXÃO COM BANCO DE DADOS:
					
					Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/petrobras", "root", "alunolab");
					
					String consulta = txtcodigo.getText();
					
		            // Executar a consulta
		           PreparedStatement pesquisa = conexao.prepareStatement("SELECT * FROM pedidos WHERE codigo = ?");
		           
		           pesquisa.setString(1, consulta);
		            
		        	ResultSet resultado = pesquisa.executeQuery();


		            // Processar os resultados
		            while (resultado.next()) {
		            	
		                // Supondo que você tenha uma coluna chamada "nome" na tabela
		            	
		            	String dataCompra = resultado.getString("data_compra");
						String dataEntrega = resultado.getString("data_entrega");				
						String quantidade = resultado.getString("quantidade");					
					
		                
						txtdataCompra.setText(dataCompra);
						txtdataEntrega.setText(dataEntrega);
						txtquantidade.setText(quantidade);
					
		                
		                
		            }
					
					//TRATANDO CONEXÃO COM BANCO DE DADOS SIM OU NÃO:
					
					} catch (Exception erro) {
						erro.printStackTrace();
						JOptionPane.showMessageDialog(null, "ERRO DE CONEXÃO COM BANCO DE DADOS");
					}
			
			
				
				
			}
		});
		
		JComboBox txtStatus = new JComboBox();
		txtStatus.setBackground(new Color(255, 255, 255));
		txtStatus.setModel(new DefaultComboBoxModel(new String[] {"Em Andamento", "Em Rota"}));
		txtStatus.setBounds(120, 264, 144, 18);
		panel.add(txtStatus);
		
		cad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		cad.setFont(new Font("Times New Roman", Font.BOLD, 12));
		cad.setBounds(130, 126, 123, 33);
		panel.add(cad);
		
		JButton atualizar = new JButton("Atualizar Status");
		atualizar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				
				try {
		            // INVOCAR O CONECTOR DO BANCO DE DADOS:
		            Class.forName("com.mysql.cj.jdbc.Driver");


		            // REALIZAR A CONEXÃO COM BANCO DE DADOS:
		            Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/petrobras", "root", "alunolab");


		            // PEGAR VALORES DAS CAIXAS DE TEXTOS:
		            String codigo = txtcodigo.getText();
		            String status = txtStatus.getSelectedItem().toString();
		            
		            // ATUALIZAR DADOS ATRAVÉS DE LINGUAGEM SQL:
		            String atualizar = "UPDATE pedidos SET status_pedido = ? WHERE codigo = ?";


		            // PREPARANDO PARA ENVIAR:
		            PreparedStatement statement = conexao.prepareStatement(atualizar);


		            statement.setString(1, status);
		            statement.setString(2, codigo);
		           


		            int resultado = statement.executeUpdate();


		            // TRATANDO CONDIÇÃO PARA SABER SE A ATUALIZAÇÃO FOI BEM-SUCEDIDA:
		            if (resultado > 0) {
		                JOptionPane.showMessageDialog(null, "DADOS ATUALIZADOS COM SUCESSO!");
		            } else {
		                JOptionPane.showMessageDialog(null, "ERRO AO ATUALIZAR DADOS, CONFIRA OS DADOS E TENTE NOVAMENTE!");
		            }


		            // FECHAR CONEXÃO COM BANCO DE DADOS:
		            conexao.close();


		        } catch (Exception erro) {
		            erro.printStackTrace();
		            JOptionPane.showMessageDialog(null, "ERRO DE CONEXÃO COM BANCO DE DADOS");
		        }

				
			}
			
			});
		atualizar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		atualizar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				
				atualizar.setCursor(new Cursor(Cursor.HAND_CURSOR));
				
			}
		});
		atualizar.setBackground(new Color(255, 255, 255));
		atualizar.setFont(new Font("Times New Roman", Font.BOLD, 12));
		atualizar.setBounds(159, 331, 123, 33);
		panel.add(atualizar);
		
		JButton limpar = new JButton("Limpar");
		limpar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				
				limpar.setCursor(new Cursor(Cursor.HAND_CURSOR));
				
			}
		});
		limpar.setBackground(new Color(255, 255, 255));
		limpar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				txtcodigo.setText("");
				txtdataCompra.setText("");
				txtdataEntrega.setText("");
				txtquantidade.setText("");
			
				
			}
		});
		limpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		limpar.setFont(new Font("Times New Roman", Font.BOLD, 12));
		limpar.setBounds(39, 331, 110, 33);
		panel.add(limpar);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("Status do Pedido:");
		lblNewLabel_1_3_1.setForeground(Color.WHITE);
		lblNewLabel_1_3_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_3_1.setBounds(15, 268, 95, 14);
		panel.add(lblNewLabel_1_3_1);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				TelaLogin abre = new TelaLogin();
				abre.setVisible(true);
				abre.setLocationRelativeTo(null);
				setVisible(false);
				
			}
		});
		btnVoltar.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnVoltar.setBackground(Color.WHITE);
		btnVoltar.setBounds(187, 426, 110, 33);
		panel.add(btnVoltar);
		
	
	}
}
