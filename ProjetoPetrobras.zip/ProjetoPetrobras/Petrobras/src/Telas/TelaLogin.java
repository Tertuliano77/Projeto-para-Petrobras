package Telas;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class TelaLogin extends JFrame {

	private JPanel contentPane;
	private JTextField txtemail;
	private JPasswordField txtsenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaLogin frame = new TelaLogin();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaLogin() {
		setResizable(false);
		setTitle("Tela Login - Petrobras");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 772, 420);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(53, 44, 400, 279);
		contentPane.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon(TelaLogin.class.getResource("/imagens/login.jpg")));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(46, 139, 87));
		panel.setBounds(319, 0, 445, 387);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("E-mail:");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setBackground(new Color(255, 204, 51));
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_2.setBounds(168, 219, 48, 14);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Senha:");
		lblNewLabel_2_1.setForeground(Color.WHITE);
		lblNewLabel_2_1.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_2_1.setBackground(new Color(255, 204, 51));
		lblNewLabel_2_1.setBounds(168, 253, 48, 14);
		panel.add(lblNewLabel_2_1);
		
		txtemail = new JTextField();
		txtemail.setBounds(226, 217, 165, 20);
		panel.add(txtemail);
		txtemail.setColumns(10);
		
		txtsenha = new JPasswordField();
		txtsenha.setColumns(10);
		txtsenha.setBounds(226, 251, 165, 20);
		panel.add(txtsenha);
		
		JButton botaoEntrar = new JButton("ENTRAR");
		botaoEntrar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				botaoEntrar.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}
		});
		botaoEntrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				
				
try {
	
	
	
					//INVOCAR O CONECTOR DO BANCO DE DADOS:
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					
					// REALIZAR A CONEXÃO COM BANCO DE DADOS:
					
					Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/petrobras", "root", "alunolab");
					
					String consulta = txtemail.getText();
					
		            // Executar a consulta
		           PreparedStatement pesquisa = conexao.prepareStatement("SELECT * FROM usuarios where email = ?");
		           
		           pesquisa.setString(1, consulta);
		            
		        	ResultSet resultado = pesquisa.executeQuery();
		        	
		        	
		        
		        	String email = "";
		        	String senha = "";
		        	String setor = "";
	
		            // Processar os resultados
		            while (resultado.next()) {//INICIO DO ENQUANTO
		            	
		                // Supondo que você tenha uma coluna chamada "nome" na tabela
		            	email = resultado.getString("email");
		                senha = resultado.getString("senha");
		                setor = resultado.getString("setor");
		               
		                
		                if(txtemail.getText().equals(email) && txtsenha.getText().equals(senha) && setor.equals("Pedido") ) {
		                	
		                	JOptionPane.showMessageDialog(null, "Seja Bem Vindo(a) ao Sistema!");
		                	
		                	TelaPedidos abre = new TelaPedidos();
		                	abre.setVisible(true);
		                	abre.setLocationRelativeTo(null);
		                	setVisible(false);
		                			                		 
		            		}else  if(txtemail.getText().equals(email) && txtsenha.getText().equals(senha) && setor.equals("Transporte") ) {
			                	
			                	JOptionPane.showMessageDialog(null, "Seja Bem Vindo(a) ao Sistema!");
			                	
			                	TelaTransporte abre = new TelaTransporte();
			                	abre.setVisible(true);
			                	abre.setLocationRelativeTo(null);
			                	setVisible(false);
			                			                		 
			            		}else if(txtemail.getText().equals(email) && txtsenha.getText().equals(senha) && setor.equals("Recebimento") ) {
				                	
				                	JOptionPane.showMessageDialog(null, "Seja Bem Vindo(a) ao Sistema!");
				                	
				                	TelaRecebimento abre = new TelaRecebimento();
				                	abre.setVisible(true);
				                	abre.setLocationRelativeTo(null);
				                	setVisible(false);
				                	
			            		}else if(txtemail.getText().equals(email) && txtsenha.getText().equals(senha) && setor.equals("Produto") ) {
				                	
				                	JOptionPane.showMessageDialog(null, "Seja Bem Vindo(a) ao Sistema!");
				                	
				                	TelaProduto abre = new TelaProduto();
				                	abre.setVisible(true);
				                	abre.setLocationRelativeTo(null);
				                	setVisible(false);
			            		}else{
		            			
		            		JOptionPane.showMessageDialog(null, "USUÁRIO OU SENHA INVÁLIDOS!");
			                
		            		}//FIMSE
		            
		                
		            }//FIM DO ENQUANTO
		            
		            
					
					//TRATANDO CONEXÃO COM BANCO DE DADOS SIM OU NÃO:
					
					} catch (Exception erro) {
						erro.printStackTrace();
						JOptionPane.showMessageDialog(null, "ERRO DE CONEXÃO COM BANCO DE DADOS");
					}
			

				
			}
		});
		botaoEntrar.setBackground(new Color(255, 255, 255));
		botaoEntrar.setFont(new Font("Times New Roman", Font.BOLD, 12));
		botaoEntrar.setBounds(250, 282, 120, 23);
		panel.add(botaoEntrar);
		
		JButton botaoCadastrar = new JButton("CADASTRAR");
		botaoCadastrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				TelaCadastro abre = new TelaCadastro();
				abre.setVisible(true);
				abre.setLocationRelativeTo(null);
				setVisible(false);
				
			}
		});
		botaoCadastrar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				botaoCadastrar.setCursor(new Cursor(Cursor.HAND_CURSOR));
			}
		});
		botaoCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				

			}
			
		});
		botaoCadastrar.setForeground(new Color(255, 255, 255));
		botaoCadastrar.setFont(new Font("Times New Roman", Font.BOLD, 12));
		botaoCadastrar.setBackground(new Color(46, 139, 87));
		botaoCadastrar.setBounds(236, 341, 155, 23);
		panel.add(botaoCadastrar);
		
		JLabel lblNewLabel_3 = new JLabel("Deseja se cadastrar no sistema?");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_3.setForeground(SystemColor.controlHighlight);
		lblNewLabel_3.setBounds(226, 316, 176, 14);
		panel.add(lblNewLabel_3);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(TelaLogin.class.getResource("/imagens/Design_sem_nome-removebg-preview (1).png")));
		lblNewLabel_1.setBounds(119, 0, 272, 299);
		panel.add(lblNewLabel_1);
	}
}
