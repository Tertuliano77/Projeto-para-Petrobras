package Telas;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class TelaPedidos extends JFrame {

	private JPanel txtrecebidos;
	private JTextField txtcodigo;
	private JTextField txtcodigoProduto;
	private JTextField txtdataCompra;
	private JTextField txtdataEntrega;
	private JTextField txtquantidade;
	private JTextField txtcpfUsu;
	private JTextField txtsetor;
	private JTextField txtcep;
	private JTextField txtrua;
	private JTextField txtbairro;
	private JTextField txtcidade;
	private JTextField txtcomplemento;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPedidos frame = new TelaPedidos();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaPedidos() {
		setResizable(false);
		setTitle("Tela Principal de Pedido - Petrobras");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 506, 523);
		txtrecebidos = new JPanel();
		txtrecebidos.setBackground(Color.WHITE);
		txtrecebidos.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(txtrecebidos);
		txtrecebidos.setLayout(null);
		
		JLabel txtRecebidos = new JLabel("0");
		txtRecebidos.setVisible(false);
		txtRecebidos.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				
				try {
		            // Invocar o conector do banco de dados:
		            Class.forName("com.mysql.cj.jdbc.Driver");


		            // Realizar a conexão com banco de dados:
		            Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/petrobras", "root", "alunolab");


		            // Preparar a consulta SQL
		            String sql = "SELECT COUNT(*) AS total_pedidos FROM pedidos WHERE status_pedido = ?";
		            PreparedStatement consulta = conexao.prepareStatement(sql);
		            consulta.setString(1, "Recebido");


		            // Executar a consulta
		            ResultSet resultado = consulta.executeQuery();


		            // Processar os resultados
		            if (resultado.next()) {
		            	
		                int totalPedidosRecebidos = resultado.getInt("total_pedidos");
		                
		                String total = String.valueOf(totalPedidosRecebidos);
		                
		                txtRecebidos.setText(total);
		               
		                
		            } else {
		            	
		                JOptionPane.showMessageDialog(null, "Nenhum resultado encontrado.");
		                
		            }


		            // Fechar a conexão com banco de dados
		            conexao.close();


		        } catch (Exception erro) {
		            erro.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Erro de conexão com banco de dados");
		        }

				
			}
		});
		txtRecebidos.setForeground(new Color(240, 248, 255));
		txtRecebidos.setFont(new Font("Tahoma", Font.BOLD, 24));
		txtRecebidos.setBounds(150, 402, 15, 33);
		txtrecebidos.add(txtRecebidos);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(46, 139, 87));
		panel.setBounds(226, 0, 264, 484);
		txtrecebidos.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Codigo:");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1.setBounds(62, 66, 46, 14);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Codigo do Produto:");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(8, 91, 100, 14);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Data de Compra:");
		lblNewLabel_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_1_1.setBounds(18, 116, 90, 14);
		panel.add(lblNewLabel_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Data de Entrega:");
		lblNewLabel_1_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_1_1_1.setBounds(18, 141, 90, 14);
		panel.add(lblNewLabel_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1 = new JLabel("Quantidade:");
		lblNewLabel_1_1_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1.setBounds(42, 166, 66, 14);
		panel.add(lblNewLabel_1_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1_1 = new JLabel("Cpf do Usuário:");
		lblNewLabel_1_1_1_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1.setBounds(26, 191, 82, 14);
		panel.add(lblNewLabel_1_1_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1_1_1 = new JLabel("Setor:");
		lblNewLabel_1_1_1_1_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1_1.setBounds(75, 216, 33, 14);
		panel.add(lblNewLabel_1_1_1_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1_1_1_1 = new JLabel("CEP:");
		lblNewLabel_1_1_1_1_1_1_1_1.setBounds(81, 241, 27, 14);
		panel.add(lblNewLabel_1_1_1_1_1_1_1_1);
		lblNewLabel_1_1_1_1_1_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1_1_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		
		JLabel lblNewLabel_1_1_1_1_1_1_1_1_1 = new JLabel("Rua:");
		lblNewLabel_1_1_1_1_1_1_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1_1_1_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1_1_1_1.setBounds(81, 266, 27, 14);
		panel.add(lblNewLabel_1_1_1_1_1_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1_1_1_1_1_1 = new JLabel("Bairro:");
		lblNewLabel_1_1_1_1_1_1_1_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1_1_1_1_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1_1_1_1_1.setBounds(70, 291, 38, 14);
		panel.add(lblNewLabel_1_1_1_1_1_1_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1_1_1_1_1_1_1 = new JLabel("Cidade:");
		lblNewLabel_1_1_1_1_1_1_1_1_1_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1_1_1_1_1_1_1_1_1_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1_1_1_1_1_1.setBounds(62, 316, 46, 14);
		panel.add(lblNewLabel_1_1_1_1_1_1_1_1_1_1_1);
		
		JLabel lblNewLabel_1_1_1_1_1_1_1_1_1_1_2 = new JLabel("Complemento:");
		lblNewLabel_1_1_1_1_1_1_1_1_1_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_1_1_1_1_1_1_1_1_1_2.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1_1_1_1_1_2.setBounds(26, 341, 82, 14);
		panel.add(lblNewLabel_1_1_1_1_1_1_1_1_1_1_2);
		
		JLabel lblNewLabel_1_1_1_1_1_1_1_1_1_1_3 = new JLabel("Status:");
		lblNewLabel_1_1_1_1_1_1_1_1_1_1_3.setForeground(Color.WHITE);
		lblNewLabel_1_1_1_1_1_1_1_1_1_1_3.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_1_1_1_1_1_1_1_1_1_3.setBounds(70, 366, 38, 14);
		panel.add(lblNewLabel_1_1_1_1_1_1_1_1_1_1_3);
		
		txtcodigo = new JTextField();
		txtcodigo.setBounds(118, 63, 138, 20);
		panel.add(txtcodigo);
		txtcodigo.setColumns(10);
		
		txtcodigoProduto = new JTextField();
		txtcodigoProduto.setColumns(10);
		txtcodigoProduto.setBounds(118, 88, 138, 20);
		panel.add(txtcodigoProduto);
		
		txtdataCompra = new JTextField();
		txtdataCompra.setColumns(10);
		txtdataCompra.setBounds(118, 113, 138, 20);
		panel.add(txtdataCompra);
		
		txtdataEntrega = new JTextField();
		txtdataEntrega.setColumns(10);
		txtdataEntrega.setBounds(118, 138, 138, 20);
		panel.add(txtdataEntrega);
		
		txtquantidade = new JTextField();
		txtquantidade.setColumns(10);
		txtquantidade.setBounds(118, 163, 138, 20);
		panel.add(txtquantidade);
		
		txtcpfUsu = new JTextField();
		txtcpfUsu.setColumns(10);
		txtcpfUsu.setBounds(118, 188, 138, 20);
		panel.add(txtcpfUsu);
		
		txtsetor = new JTextField();
		txtsetor.setColumns(10);
		txtsetor.setBounds(118, 213, 138, 20);
		panel.add(txtsetor);
		
		txtcep = new JTextField();
		txtcep.setColumns(10);
		txtcep.setBounds(118, 238, 138, 20);
		panel.add(txtcep);
		
		txtrua = new JTextField();
		txtrua.setColumns(10);
		txtrua.setBounds(118, 263, 138, 20);
		panel.add(txtrua);
		
		txtbairro = new JTextField();
		txtbairro.setColumns(10);
		txtbairro.setBounds(118, 288, 138, 20);
		panel.add(txtbairro);
		
		txtcidade = new JTextField();
		txtcidade.setColumns(10);
		txtcidade.setBounds(118, 313, 138, 20);
		panel.add(txtcidade);
		
		txtcomplemento = new JTextField();
		txtcomplemento.setColumns(10);
		txtcomplemento.setBounds(118, 338, 138, 20);
		panel.add(txtcomplemento);
		
		JComboBox txtstatus = new JComboBox();
		txtstatus.setModel(new DefaultComboBoxModel(new String[] {"Em Andamento", "Em rota", "Recebido"}));
		txtstatus.setBounds(118, 362, 138, 22);
		panel.add(txtstatus);
		
		JButton botaoCadastrar = new JButton("Cadastrar");
		botaoCadastrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					
					Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/petrobras", "root", "alunolab");
					
					String codigo = txtcodigo.getText();
					String codigo_produto = txtcodigoProduto.getText();
					String data_compra = txtdataCompra.getText();
					String data_entrega = txtdataEntrega.getText();
					String quantidade = txtquantidade.getText();
					String cpf_usu = txtcpfUsu.getText();										
					String setor = txtsetor.getText();
					String cep = txtcep.getText();
					String rua = txtrua.getText();
					String bairro = txtbairro.getText();
					String cidade = txtcidade.getText();
					String complemento = txtcomplemento.getText();
					String status = txtstatus.getSelectedItem().toString();
									
					int qtd = Integer.parseInt(quantidade);
					
					String inserir = "INSERT INTO pedidos( codigo, cod_produto, data_compra, data_entrega, quantidade,cpf_usuario,setor,cep,rua,bairro,cidade,complemento,status_pedido) VALUES (?, ?, ?, ?,?,?,?,?,?,?,?,?,?)";
					
					//PREPARANDO PARA ENVIAR:
					
					PreparedStatement statement = conexao.prepareStatement(inserir);
					
					statement.setString(1 , codigo);
					statement.setString(2 , codigo_produto);
					statement.setString(3, data_compra);
					statement.setString(4 , data_entrega);
				    statement.setInt(5 , qtd);
				    statement.setString(6 , cpf_usu);
				    statement.setString(7 , setor);
				    statement.setString(8 , cep);
				    statement.setString(9 , rua);
				    statement.setString(10 , bairro);
				    statement.setString(11 , cidade);
				    statement.setString(12 , complemento);
				    statement.setString(13 , status);
					
					int resultado = statement.executeUpdate();
					
					//TRATANDO CONDIÇÃO PARA SABER A A LINHA DO CADASTRO SERÁ PREENCHIDA:
					
					if (resultado > 0) {
						JOptionPane.showMessageDialog(null, "PEDIDO CADASTRADO COM SUCESSO!");
						
						
					}else{
							JOptionPane.showMessageDialog(null, "ERRO DE CADASTRO, CONFIRA OS DADOS E TENTE NOVAMENTE!");
						}
					
					//TRATANDO CONEXÃO COM BANCO DE DADOS SIM OU NÃO:
					
              }catch (Exception erro) {
						erro.printStackTrace();
						JOptionPane.showMessageDialog(null, "ERRO DE CONEXÃO COM BANCO DE DADOS");
              }
				
			}
		});
		botaoCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		botaoCadastrar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				
				botaoCadastrar.setCursor(new Cursor(Cursor.HAND_CURSOR));
				
			}
		});
		botaoCadastrar.setForeground(new Color(255, 255, 255));
		botaoCadastrar.setBackground(new Color(46, 139, 87));
		botaoCadastrar.setFont(new Font("Times New Roman", Font.BOLD, 15));
		botaoCadastrar.setBounds(118, 395, 138, 23);
		panel.add(botaoCadastrar);
		
		JButton btnLimpar = new JButton("Limpar");
		btnLimpar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnLimpar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				txtcodigo.setText("");
				txtcodigoProduto.setText("");
				txtdataCompra.setText("");
				txtdataEntrega.setText("");
				txtquantidade.setText("");
				txtcpfUsu.setText("");
				txtsetor.setText("");
				txtcep.setText("");
				txtrua.setText("");
				txtbairro.setText("");
				txtcidade.setText("");
				txtcomplemento.setText("");
				
				
			}
		});
		btnLimpar.setForeground(Color.WHITE);
		btnLimpar.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnLimpar.setBackground(new Color(46, 139, 87));
		btnLimpar.setBounds(118, 421, 138, 23);
		panel.add(btnLimpar);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				TelaLogin abre = new TelaLogin();
				abre.setVisible(true);
				abre.setLocationRelativeTo(null);
				setVisible(false);
				
			}
		});
		btnVoltar.setForeground(Color.WHITE);
		btnVoltar.setFont(new Font("Times New Roman", Font.BOLD, 15));
		btnVoltar.setBackground(new Color(46, 139, 87));
		btnVoltar.setBounds(8, 450, 100, 23);
		panel.add(btnVoltar);
		
		
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(TelaPedidos.class.getResource("/imagens/login (1).jpg")));
		lblNewLabel.setBounds(22, 116, 176, 176);
		txtrecebidos.add(lblNewLabel);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent e) {
				
				txtRecebidos.setVisible(false);
				
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				
				TabelaPedidoRecebido abre = new TabelaPedidoRecebido();
				abre.setVisible(true);
				abre.setLocationRelativeTo(null);
				
			}
		});
		lblNewLabel_3.addMouseMotionListener(new MouseMotionAdapter() {
			
		
			
			@Override
			public void mouseMoved(MouseEvent e) {
				
				lblNewLabel_3.setCursor(new Cursor(Cursor.HAND_CURSOR));

				try {
		            // Invocar o conector do banco de dados:
		            Class.forName("com.mysql.cj.jdbc.Driver");


		            // Realizar a conexão com banco de dados:
		            Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/petrobras", "root", "alunolab");


		            // Preparar a consulta SQL
		            String sql = "SELECT COUNT(*) AS total_pedidos FROM pedidos WHERE status_pedido = ?";
		            PreparedStatement consulta = conexao.prepareStatement(sql);
		            consulta.setString(1, "Recebido");


		            // Executar a consulta
		            ResultSet resultado = consulta.executeQuery();


		            // Processar os resultados
		            if (resultado.next()) {
		            	
		                int totalPedidosRecebidos = resultado.getInt("total_pedidos");
		                
		                String total = String.valueOf(totalPedidosRecebidos);
		                
		                txtRecebidos.setText(total);
		                txtRecebidos.setVisible(true);
		               
		                
		            } else {
		            	
		                JOptionPane.showMessageDialog(null, "Nenhum resultado encontrado.");
		                
		            }


		            // Fechar a conexão com banco de dados
		            conexao.close();


		        } catch (Exception erro) {
		            erro.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Erro de conexão com banco de dados");
		        }

			}
		}
			
			
		);
		lblNewLabel_3.setIcon(new ImageIcon(TelaPedidos.class.getResource("/imagens/recebido (3) (2).png")));
		lblNewLabel_3.setBounds(117, 373, 99, 85);
		txtrecebidos.add(lblNewLabel_3);
		
		JLabel txtPedidos = new JLabel("0");
		txtPedidos.setVisible(false);
		txtPedidos.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent e) {
				
				
				
			}
		});
		txtPedidos.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				
			
			}
		});
		txtPedidos.setForeground(new Color(240, 248, 255));
		txtPedidos.setFont(new Font("Tahoma", Font.BOLD, 24));
		txtPedidos.setBounds(47, 402, 15, 33);
		txtrecebidos.add(txtPedidos);
		
		JLabel jlabel = new JLabel("");
		jlabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseExited(MouseEvent e) {
				
				txtPedidos.setVisible(false);
				
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				
				TabelaPedidoRota abre = new TabelaPedidoRota();
				abre.setVisible(true);
				abre.setLocationRelativeTo(null);
				
						
				
			}
		}
			
			
		
		);
		jlabel.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				
				jlabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
				
				try {
		            // Invocar o conector do banco de dados:
		            Class.forName("com.mysql.cj.jdbc.Driver");


		            // Realizar a conexão com banco de dados:
		            Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/petrobras", "root", "alunolab");


		            // Preparar a consulta SQL
		            String sql = "SELECT COUNT(*) AS total_pedidos FROM pedidos WHERE status_pedido = ?";
		            PreparedStatement consulta = conexao.prepareStatement(sql);
		            consulta.setString(1, "Em Rota");


		            // Executar a consulta
		            ResultSet resultado = consulta.executeQuery();


		            // Processar os resultados
		            if (resultado.next()) {
		            	
		                int totalPedidosEmRota = resultado.getInt("total_pedidos");
		                
		                String total = String.valueOf(totalPedidosEmRota);
		                
		                txtPedidos.setText(total);
		                txtPedidos.setVisible(true);
		               
		                
		            } else {
		            	
		                JOptionPane.showMessageDialog(null, "Nenhum resultado encontrado.");
		                
		            }


		            // Fechar a conexão com banco de dados
		            conexao.close();


		        } catch (Exception erro) {
		            erro.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Erro de conexão com banco de dados");
		        }

			}
				
			});
		jlabel.setForeground(new Color(0, 0, 0));
		jlabel.setIcon(new ImageIcon(TelaPedidos.class.getResource("/imagens/rota (1) (1) (1).jpg")));
		jlabel.setBounds(0, 362, 97, 85);
		txtrecebidos.add(jlabel);
	}
}

