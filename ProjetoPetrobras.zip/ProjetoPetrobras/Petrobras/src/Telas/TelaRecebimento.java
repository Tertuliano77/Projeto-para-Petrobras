package Telas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.MouseMotionAdapter;

public class TelaRecebimento extends JFrame {

	private JPanel contentPane;
	private JTextField txtcodigo;
	private JTextField txtdataCompra;
	private JTextField txtdataEntrega;
	private JTextField txtquantidade;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaRecebimento frame = new TelaRecebimento();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
					frame.setLocationRelativeTo(null);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaRecebimento() {
		setResizable(false);
		setTitle("Tela Principal de Recebimento - Petrobras");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 526, 509);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(46, 139, 87));
		panel.setBounds(214, 0, 327, 470);
		contentPane.add(panel);
		panel.setLayout(null);
		
		txtcodigo = new JTextField();
		txtcodigo.setColumns(10);
		txtcodigo.setBounds(120, 85, 144, 20);
		panel.add(txtcodigo);
		
		JButton cad = new JButton("Consultar");
		cad.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				
				cad.setCursor(new Cursor(Cursor.HAND_CURSOR));
				
			}
		});
		cad.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
try {
					
					//INVOCAR O CONECTOR DO BANCO DE DADOS:
					
					Class.forName("com.mysql.cj.jdbc.Driver");
					
					// REALIZAR A CONEXÃO COM BANCO DE DADOS:
					
					Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/petrobras", "root", "alunolab");
					
					String consulta = txtcodigo.getText();
					
		            // Executar a consulta
		           PreparedStatement pesquisa = conexao.prepareStatement("SELECT * FROM pedidos WHERE codigo = ?");
		           
		           pesquisa.setString(1, consulta);
		            
		        	ResultSet resultado = pesquisa.executeQuery();


		            // Processar os resultados
		            while (resultado.next()) {
		            	
		                // Supondo que você tenha uma coluna chamada "nome" na tabela
		            	
		            	String dataCompra = resultado.getString("data_compra");
						String dataEntrega = resultado.getString("data_entrega");				
						String quantidade = resultado.getString("quantidade");					
					
		                
						txtdataCompra.setText(dataCompra);
						txtdataEntrega.setText(dataEntrega);
						txtquantidade.setText(quantidade);
					
		                
		                
		            }
					
					//TRATANDO CONEXÃO COM BANCO DE DADOS SIM OU NÃO:
					
					} catch (Exception erro) {
						erro.printStackTrace();
						JOptionPane.showMessageDialog(null, "ERRO DE CONEXÃO COM BANCO DE DADOS");
					}
			
			
				
				
			}
				
			
		});
		cad.setFont(new Font("Times New Roman", Font.BOLD, 12));
		cad.setBackground(Color.WHITE);
		cad.setBounds(130, 131, 123, 33);
		panel.add(cad);
		
		JLabel lblNewLabel_1 = new JLabel("Código do Pedido:");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1.setBounds(10, 88, 100, 14);
		panel.add(lblNewLabel_1);
		
		txtdataCompra = new JTextField();
		txtdataCompra.setEditable(false);
		txtdataCompra.setColumns(10);
		txtdataCompra.setBounds(120, 194, 144, 20);
		panel.add(txtdataCompra);
		
		JLabel lblNewLabel_1_1 = new JLabel("Data da Compra:");
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(21, 198, 89, 14);
		panel.add(lblNewLabel_1_1);
		
		txtdataEntrega = new JTextField();
		txtdataEntrega.setEditable(false);
		txtdataEntrega.setColumns(10);
		txtdataEntrega.setBounds(120, 220, 144, 20);
		panel.add(txtdataEntrega);
		
		JLabel lblNewLabel_1_2 = new JLabel("Data de Entrega:");
		lblNewLabel_1_2.setForeground(Color.WHITE);
		lblNewLabel_1_2.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_2.setBounds(21, 223, 89, 14);
		panel.add(lblNewLabel_1_2);
		
		txtquantidade = new JTextField();
		txtquantidade.setEditable(false);
		txtquantidade.setColumns(10);
		txtquantidade.setBounds(120, 245, 144, 20);
		panel.add(txtquantidade);
		
		JLabel lblNewLabel_1_3 = new JLabel("Quantidade:");
		lblNewLabel_1_3.setForeground(Color.WHITE);
		lblNewLabel_1_3.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_3.setBounds(44, 248, 66, 14);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("Status do Pedido:");
		lblNewLabel_1_3_1.setForeground(Color.WHITE);
		lblNewLabel_1_3_1.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblNewLabel_1_3_1.setBounds(15, 273, 95, 14);
		panel.add(lblNewLabel_1_3_1);
		
		JComboBox txtStatus = new JComboBox();
		txtStatus.setModel(new DefaultComboBoxModel(new String[] {"Recebido", ""}));
		txtStatus.setBackground(Color.WHITE);
		txtStatus.setBounds(120, 269, 144, 18);
		panel.add(txtStatus);
		
		JButton limpar = new JButton("Limpar");
		limpar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				
				limpar.setCursor(new Cursor(Cursor.HAND_CURSOR));
				
			}
		});
		limpar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				txtcodigo.setText("");
				txtdataCompra.setText("");
				txtdataEntrega.setText("");
				txtquantidade.setText("");
			
				
			}
		});
		limpar.setFont(new Font("Times New Roman", Font.BOLD, 12));
		limpar.setBackground(Color.WHITE);
		limpar.setBounds(39, 336, 110, 33);
		panel.add(limpar);
		
		JButton atualizar = new JButton("Atualizar Status");
		atualizar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				try {
		            // INVOCAR O CONECTOR DO BANCO DE DADOS:
		            Class.forName("com.mysql.cj.jdbc.Driver");


		            // REALIZAR A CONEXÃO COM BANCO DE DADOS:
		            Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/petrobras", "root", "alunolab");


		            // PEGAR VALORES DAS CAIXAS DE TEXTOS:
		            String codigo = txtcodigo.getText();
		            String status = txtStatus.getSelectedItem().toString();
		            
		            // ATUALIZAR DADOS ATRAVÉS DE LINGUAGEM SQL:
		            String atualizar = "UPDATE pedidos SET status_pedido = ? WHERE codigo = ?";


		            // PREPARANDO PARA ENVIAR:
		            PreparedStatement statement = conexao.prepareStatement(atualizar);


		            statement.setString(1, status);
		            statement.setString(2, codigo);
		           


		            int resultado = statement.executeUpdate();


		            // TRATANDO CONDIÇÃO PARA SABER SE A ATUALIZAÇÃO FOI BEM-SUCEDIDA:
		            if (resultado > 0) {
		                JOptionPane.showMessageDialog(null, "DADOS ATUALIZADOS COM SUCESSO!");
		            } else {
		                JOptionPane.showMessageDialog(null, "ERRO AO ATUALIZAR DADOS, CONFIRA OS DADOS E TENTE NOVAMENTE!");
		            }


		            // FECHAR CONEXÃO COM BANCO DE DADOS:
		            conexao.close();


		        } catch (Exception erro) {
		            erro.printStackTrace();
		            JOptionPane.showMessageDialog(null, "ERRO DE CONEXÃO COM BANCO DE DADOS");
		        }

				
			}
				
			
		});
		atualizar.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				
				atualizar.setCursor(new Cursor(Cursor.HAND_CURSOR));
				
			}
		});
		atualizar.setFont(new Font("Times New Roman", Font.BOLD, 12));
		atualizar.setBackground(Color.WHITE);
		atualizar.setBounds(159, 336, 123, 33);
		panel.add(atualizar);
		
		JButton btnVoltar = new JButton("Voltar");
		btnVoltar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				TelaLogin abre = new TelaLogin();
				abre.setVisible(true);
				abre.setLocationRelativeTo(null);
				setVisible(false);
				
			}
		});
		btnVoltar.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnVoltar.setBackground(Color.WHITE);
		btnVoltar.setBounds(172, 426, 110, 33);
		panel.add(btnVoltar);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(TelaRecebimento.class.getResource("/imagens/login (1).jpg")));
		lblNewLabel.setBounds(10, 118, 195, 198);
		contentPane.add(lblNewLabel);
	}
}
