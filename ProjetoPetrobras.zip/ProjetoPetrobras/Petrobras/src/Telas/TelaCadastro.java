package Telas;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.MouseAdapter;

public class TelaCadastro extends JFrame {

	private JPanel contentPane;
	private JTextField txtcpfUsu;
	private JTextField txtusu;
	private JTextField txtemail;
	private JTextField txtsenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaCadastro frame = new TelaCadastro();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaCadastro() {
		setResizable(false);
		setTitle("Tela de Cadastrar Usuário - Petrobras");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 482, 486);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(46, 139, 87));
		panel.setBounds(231, 0, 235, 447);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JComboBox txtsetor = new JComboBox();
		txtsetor.setModel(new DefaultComboBoxModel(new String[] {"Pedido", "Produto", "Transporte", "Recebimento"}));
		txtsetor.setBounds(96, 240, 108, 22);
		panel.add(txtsetor);
		
		JButton btcad = new JButton("Cadastrar");
		btcad.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Class.forName("com.mysql.cj.jdbc.Driver");
					
					Connection conexao = DriverManager.getConnection("jdbc:mysql://localhost:3306/petrobras", "root", "alunolab");
					
					String cpf = txtcpfUsu.getText();										
					String usuario = txtusu.getText();
					String email = txtemail.getText();
					String senha = txtsenha.getText();
					String setor = txtsetor.getSelectedItem().toString();
																																	
					String inserir = "INSERT INTO usuarios( cpf, usuario, email, senha, setor) VALUES (?, ?, ?, ?,?)";
					
					//PREPARANDO PARA ENVIAR:
					
					PreparedStatement statement = conexao.prepareStatement(inserir);
					
					statement.setString(1 , cpf);
					statement.setString(2 , usuario);
					statement.setString(3, email);
					statement.setString(4 , senha);
				    statement.setString(5 , setor);
					
					int resultado = statement.executeUpdate();
					
					//TRATANDO CONDIÇÃO PARA SABER A A LINHA DO CADASTRO SERÁ PREENCHIDA:
					
					if (resultado > 0) {
						JOptionPane.showMessageDialog(null, "USUÁRIO CADASTRADO COM SUCESSO!");
						
						TelaLogin abre = new TelaLogin();
						abre.setVisible(true);
						abre.setLocationRelativeTo(null);
						setVisible(false);
					}else{
							JOptionPane.showMessageDialog(null, "ERRO DE CADASTRO, CONFIRA OS DADOS E TENTE NOVAMENTE!");
						}
					
					//TRATANDO CONEXÃO COM BANCO DE DADOS SIM OU NÃO:
					
              }catch (Exception erro) {
						erro.printStackTrace();
						JOptionPane.showMessageDialog(null, "ERRO DE CONEXÃO COM BANCO DE DADOS");
              }
}
		});
		btcad.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent e) {
				
				btcad.setCursor(new Cursor(Cursor.HAND_CURSOR));
				
			}
		});
		btcad.setBounds(96, 288, 108, 23);
		panel.add(btcad);
		btcad.setForeground(Color.WHITE);
		btcad.setBackground(new Color(46, 139, 87));
		btcad.setFont(new Font("Times New Roman", Font.BOLD, 12));
		
		JLabel lblNewLabel = new JLabel("CPF:");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(59, 137, 27, 14);
		panel.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 12));
		
		txtcpfUsu = new JTextField();
		txtcpfUsu.setBounds(96, 134, 108, 20);
		panel.add(txtcpfUsu);
		txtcpfUsu.setColumns(10);
		
		JLabel lblUsurio = new JLabel("Usuário:");
		lblUsurio.setForeground(Color.WHITE);
		lblUsurio.setBounds(41, 162, 45, 14);
		panel.add(lblUsurio);
		lblUsurio.setFont(new Font("Times New Roman", Font.BOLD, 12));
		
		txtusu = new JTextField();
		txtusu.setBounds(96, 159, 108, 20);
		panel.add(txtusu);
		txtusu.setColumns(10);
		
		JLabel lblEmail = new JLabel("E-mail:");
		lblEmail.setForeground(Color.WHITE);
		lblEmail.setBounds(47, 187, 39, 14);
		panel.add(lblEmail);
		lblEmail.setFont(new Font("Times New Roman", Font.BOLD, 12));
		
		txtemail = new JTextField();
		txtemail.setBounds(96, 184, 108, 20);
		panel.add(txtemail);
		txtemail.setColumns(10);
		
		JLabel lblSenha = new JLabel("Senha:");
		lblSenha.setForeground(Color.WHITE);
		lblSenha.setBounds(47, 212, 39, 14);
		panel.add(lblSenha);
		lblSenha.setFont(new Font("Times New Roman", Font.BOLD, 12));
		
		txtsenha = new JTextField();
		txtsenha.setBounds(96, 209, 108, 20);
		panel.add(txtsenha);
		txtsenha.setColumns(10);
		
		JLabel lblSetor = new JLabel("Setor:");
		lblSetor.setForeground(Color.WHITE);
		lblSetor.setBounds(53, 237, 33, 14);
		panel.add(lblSetor);
		lblSetor.setFont(new Font("Times New Roman", Font.BOLD, 12));
		
		JButton btnLimpar = new JButton("Limpar");
		btnLimpar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				txtcpfUsu.setText("");
				txtusu.setText("");
				txtemail.setText("");
				txtsenha.setText("");
				
			}
		});
		btnLimpar.setForeground(Color.WHITE);
		btnLimpar.setFont(new Font("Times New Roman", Font.BOLD, 12));
		btnLimpar.setBackground(new Color(46, 139, 87));
		btnLimpar.setBounds(96, 322, 108, 23);
		panel.add(btnLimpar);
		
		
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(TelaCadastro.class.getResource("/imagens/login (1).jpg")));
		lblNewLabel_1.setBounds(21, 102, 183, 225);
		contentPane.add(lblNewLabel_1);
	}
}
