
create schema petrobras;
use petrobras;

create table  produto(
    codigo varchar(30) not null,
nome varchar(30) not null,
descricao varchar(100) not null,
quantidade int not null,
validade varchar(30) not null,
fornecedor varchar(30) not null,

PRIMARY KEY(codigo)
);

create table  usuarios(
    cpf varchar(20) not null,
usuario varchar(30) not null,
email varchar(50) not null,
senha varchar(20) not null,
setor varchar(30) not null,

PRIMARY KEY(cpf)
);

create table pedidos(
codigo varchar(20) not null primary key,
cod_produto varchar(30) not null,
data_compra varchar(30) not null,
data_entrega varchar(30) not null,
quantidade int not null,
cpf_usuario varchar(20) not null,
setor varchar(30) not null,
cep varchar(30) not null,
rua varchar(50) not null,
bairro varchar(50) not null,
cidade varchar(50) not null,
complemento varchar(50) not null,
status_pedido varchar(50) not null,

FOREIGN KEY (cod_produto)REFERENCES produto(codigo),
FOREIGN KEY(cpf_usuario)REFERENCES usuarios(cpf)
)
